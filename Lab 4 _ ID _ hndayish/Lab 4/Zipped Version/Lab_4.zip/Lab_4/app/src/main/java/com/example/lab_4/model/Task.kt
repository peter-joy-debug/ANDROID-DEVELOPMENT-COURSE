package com.example.lab_4.model

data class Task(val taskId: String, val taskTitle:String, val taskDescription: String, val isCompleted: Boolean)
{

}