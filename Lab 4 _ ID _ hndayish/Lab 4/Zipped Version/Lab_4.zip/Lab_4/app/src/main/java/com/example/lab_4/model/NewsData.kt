package com.example.lab_4.model

import com.example.lab_4.R

val newsData = listOf(
    NewsDataModel(
        "Sport",
        4.0f,
        "Today is the day of sport",
        R.drawable.n5
    ),
    NewsDataModel(
        "Music",
        4.5f,
        "Music is for relaxing",
        R.drawable.n7
    ),
    NewsDataModel(
        "Space",
        5.0f,
        "Recently, NASA launced SpaceJ9 Satelite ",
        R.drawable.n8
    ),
    NewsDataModel(
        "Business",
        3.5f,
        "Take your time to invest your profit",
        R.drawable.n9
    ),
    NewsDataModel(
        "Entertainment",
        2.0f,
        "We all like to dance",
        R.drawable.n2
    )
)