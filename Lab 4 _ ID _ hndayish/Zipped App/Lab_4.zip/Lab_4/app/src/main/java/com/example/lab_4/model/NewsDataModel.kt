package com.example.lab_4.model

data class NewsDataModel(
    val title: String,
    val rating: Float,
    val desc: String,
    val imgUrl: Int
)
{

}